9WOKE Minecraft Real (GOD MODE B - real survival)

1) Copy this folder into your tool/ project OR run standalone.
2) Rename .env.example -> .env and edit MC_HOST/MC_PORT.
3) In Minecraft server, make sure you allow bots to join (online-mode/offline-mode accordingly).
4) OP either 9woke or DirectorBot if you want /give and /tp to work.

Run (3 terminals):
  npm install
  npm run bot:civ
  npm run bot:director
  npm run story

Or series:
  npm run series
