const path = require('path')
require('dotenv').config()

function must(key, def) {
  return process.env[key] || def
}

const config = {
  mc: {
    host: must('MC_HOST', '127.0.0.1'),
    port: Number(must('MC_PORT', '25565')),
    version: must('MC_VERSION', '1.20.1'),

    botCivName: must('MC_BOT_CIV_USERNAME', 'CivilizationBot'),
    botCamName: must('MC_BOT_CAM_USERNAME', 'CameraBot'),
    botDirectorName: must('MC_BOT_DIRECTOR_USERNAME', 'DirectorBot'),
  },

  obs: {
    host: must('OBS_HOST', '127.0.0.1'),
    port: Number(must('OBS_PORT', '4455')),
    password: must('OBS_PASSWORD', ''),
  },

  paths: {
    recordingsDir: path.resolve(must('RECORDINGS_DIR', 'recordings')),
    markersDir: path.resolve(must('MARKERS_DIR', 'markers')),
    eventsDir: path.resolve(must('EVENTS_DIR', 'data/events')),
    outputsDir: path.resolve(must('OUTPUTS_DIR', 'outputs')),

    runtimeDir: path.resolve(must('RUNTIME_DIR', 'runtime')),
    commandBusPath: path.resolve(must('COMMAND_BUS', 'runtime/command_bus.jsonl')),
  },

  cinematic: {
    cameraTickMs: Number(must('CAMERA_TICK_MS', '120')),
    cameraRadius: Number(must('CAMERA_RADIUS', '18')),
    cameraHeight: Number(must('CAMERA_HEIGHT', '6')),
    orbitSpeed: Number(must('ORBIT_SPEED', '0.02')),
    dollySpeed: Number(must('DOLLY_SPEED', '0.015')),
  },

  city: {
    baseStep: Number(must('CITY_STEP', '16')),
    maxLevel: Number(must('CITY_MAX_LEVEL', '5')),
  },

  war: {
    maxAllies: Number(must('WAR_MAX_ALLIES', '6')),
    maxEnemies: Number(must('WAR_MAX_ENEMIES', '10')),
  }
}

module.exports = config
