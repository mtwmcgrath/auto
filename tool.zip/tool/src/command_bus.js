const fs = require('fs')
const fsp = fs.promises
const path = require('path')
const log = require('./logger')

async function ensureFile(filePath) {
  await fsp.mkdir(path.dirname(filePath), { recursive: true })
  if (!fs.existsSync(filePath)) await fsp.writeFile(filePath, '', 'utf8')
}

async function clearBus(filePath) {
  await ensureFile(filePath)
  await fsp.writeFile(filePath, '', 'utf8')
}

async function publish(filePath, msg) {
  await ensureFile(filePath)
  const line = JSON.stringify({ t: Date.now(), ...msg }) + '\n'
  await fsp.appendFile(filePath, line, 'utf8')
}

class Tailer {
  constructor(filePath) {
    this.filePath = filePath
    this.offset = 0
  }

  async readNew() {
    await ensureFile(this.filePath)
    const st = await fsp.stat(this.filePath)
    if (st.size <= this.offset) return []
    const fh = await fsp.open(this.filePath, 'r')
    try {
      const len = st.size - this.offset
      const buf = Buffer.alloc(len)
      await fh.read(buf, 0, len, this.offset)
      this.offset = st.size
      const text = buf.toString('utf8')
      return text.split('\n').filter(Boolean).map(line => {
        try { return JSON.parse(line) } catch { return null }
      }).filter(Boolean)
    } finally {
      await fh.close()
    }
  }
}

module.exports = { publish, clearBus, Tailer }
