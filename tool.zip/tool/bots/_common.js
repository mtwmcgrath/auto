const mineflayer = require('mineflayer')
const { mc } = require('../src/config')
function createBot(username) {
  return mineflayer.createBot({ host: mc.host, port: mc.port, username })
}
module.exports = { createBot }
