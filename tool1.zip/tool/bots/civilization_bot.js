const { createBot } = require('./_common')
const log = require('../src/logger')
const { paths } = require('../src/config')
const { Tailer } = require('../src/command_bus')

const bot = createBot(process.env.MC_BOT_CIV_USERNAME || 'CivilizationBot')
const tail = new Tailer(paths.commandBusPath)

bot.once('spawn', () => {
  log.ok('🤖 Civilization bot spawned')
  bot.chat('/gamerule sendCommandFeedback false')
  bot.chat('/gamemode survival')
  bot.chat('/title @a title {"text":"CIVILIZATION EXPERIMENT","color":"gold"}')
  bot.chat('/title @a subtitle {"text":"GOD MODE Cinematic","color":"white"}')
  setInterval(pollBus, 250)
})

function say(t) {
  const safe = (t || '').replace(/"/g, "'")
  bot.chat(`/say ${safe}`)
}

async function pollBus(){
  const msgs = await tail.readNew()
  for (const m of msgs){
    if (m.kind !== 'CIV') continue
    if (m.action === 'NARRATE'){
      say(m.text)
      bot.chat(`/title @a subtitle {"text":"${(m.type||'EVENT')} - Year ${(m.year??'?')}","color":"yellow"}`)
    }
  }
}
