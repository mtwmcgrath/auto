// bots/director_bot.js
// DirectorBot: listens to story/events in chat and triggers actions (build / spawn / war).
// Includes anti-spam command queue to avoid ECONNABORTED / kick.

const { createBot } = require('./_common')
const log = require('../src/logger')

const USERNAME = process.env.MC_BOT_DIRECTOR_USERNAME || 'DirectorBot'

// --- Tunables (anti-kick) ---
const CMD_DELAY_MS = parseInt(process.env.DIRECTOR_CMD_DELAY_MS || '450', 10) // 350-700 ok
const BURST_PAUSE_EVERY = parseInt(process.env.DIRECTOR_BURST_PAUSE_EVERY || '8', 10) // pause every N commands
const BURST_PAUSE_MS = parseInt(process.env.DIRECTOR_BURST_PAUSE_MS || '1200', 10)

const bot = createBot(USERNAME)

// ----------------------------
// Robust logging (find real kick reason)
// ----------------------------
bot.on('kicked', (reason) => {
  console.log('❌ KICKED:', reason)
})
bot.on('end', () => {
  console.log('⚠️ END: connection closed by server/client')
})
bot.on('error', (err) => {
  console.log('❌ ERROR:', err)
})

// ----------------------------
// Command queue (anti-spam)
// ----------------------------
const q = []
let running = false
let sentCount = 0

function wait(ms) {
  return new Promise((r) => setTimeout(r, ms))
}

function enqueue(cmd) {
  if (!cmd || typeof cmd !== 'string') return
  q.push(cmd)
  if (!running) runQueue().catch(() => {})
}

async function runQueue() {
  running = true
  while (q.length > 0) {
    const cmd = q.shift()
    try {
      bot.chat(cmd)
      sentCount++
    } catch (e) {
      console.log('⚠️ chat send failed:', e?.message || e)
    }

    // small delay between every command
    await wait(CMD_DELAY_MS)

    // bigger pause every burst
    if (sentCount % BURST_PAUSE_EVERY === 0) {
      await wait(BURST_PAUSE_MS)
    }
  }
  running = false
}

// Helpers
function say(msg) {
  enqueue(`/say ${msg}`)
}
function cmd(s) {
  enqueue(s.startsWith('/') ? s : `/${s}`)
}

// ----------------------------
// Build / Spawn / War routines (server-command based, reliable for YouTube)
// ----------------------------
function getHere() {
  const p = bot.entity.position
  return {
    x: Math.floor(p.x),
    y: Math.floor(p.y),
    z: Math.floor(p.z),
  }
}

function buildHut() {
  const { x, y, z } = getHere()

  // clear area + floor + walls + roof + door
  cmd(`fill ${x - 6} ${y - 1} ${z - 6} ${x + 14} ${y - 1} ${z + 14} stone_bricks`)
  cmd(`fill ${x + 2} ${y} ${z + 2} ${x + 10} ${y + 6} ${z + 10} air`)
  cmd(`fill ${x + 2} ${y} ${z + 2} ${x + 10} ${y} ${z + 10} oak_planks`)

  // walls (logs)
  cmd(`fill ${x + 2} ${y + 1} ${z + 2} ${x + 10} ${y + 4} ${z + 2} oak_log`)
  cmd(`fill ${x + 2} ${y + 1} ${z + 10} ${x + 10} ${y + 4} ${z + 10} oak_log`)
  cmd(`fill ${x + 2} ${y + 1} ${z + 2} ${x + 2} ${y + 4} ${z + 10} oak_log`)
  cmd(`fill ${x + 10} ${y + 1} ${z + 2} ${x + 10} ${y + 4} ${z + 10} oak_log`)

  // roof
  cmd(`fill ${x + 2} ${y + 5} ${z + 2} ${x + 10} ${y + 5} ${z + 10} oak_planks`)

  // door + torch
  cmd(`setblock ${x + 6} ${y + 1} ${z + 2} oak_door`)
  cmd(`setblock ${x + 6} ${y + 3} ${z + 3} torch`)

  say('✅ BUILD: Hut constructed.')
}

function spawnNPCs() {
  const { x, y, z } = getHere()
  cmd(`summon villager ${x + 6} ${y + 1} ${z + 6}`)
  cmd(`summon villager ${x + 7} ${y + 1} ${z + 6}`)
  cmd(`summon iron_golem ${x + 4} ${y + 1} ${z + 8}`)
  say('✅ NPC: Villagers and guard spawned.')
}

function startWar() {
  const { x, y, z } = getHere()

  // two sides
  cmd(`summon iron_golem ${x - 10} ${y + 1} ${z - 2}`)
  cmd(`summon iron_golem ${x - 12} ${y + 1} ${z + 2}`)

  cmd(`summon zombie ${x + 18} ${y + 1} ${z}`)
  cmd(`summon zombie ${x + 20} ${y + 1} ${z + 2}`)
  cmd(`summon skeleton ${x + 22} ${y + 1} ${z + 1}`)
  cmd(`summon skeleton ${x + 24} ${y + 1} ${z - 1}`)

  say('⚔️ WAR: Battle started!')
}

// ----------------------------
// Auto mode: react to story keywords in chat
// ----------------------------
let autoEnabled = true
const seen = new Set()

function triggerOnce(key, fn) {
  if (seen.has(key)) return
  seen.add(key)
  fn()
}

function maybeTriggerFromMessage(m) {
  const msg = m.toUpperCase()

  // story signals
  if (msg.includes('CITY_FOUNDED')) {
    triggerOnce('CITY_FOUNDED', () => {
      say('🎬 Director: CITY_FOUNDED detected → build + npc')
      buildHut()
      spawnNPCs()
    })
  }

  if (msg.includes('KING_CROWNED')) {
    triggerOnce('KING_CROWNED', () => {
      say('👑 Director: KING_CROWNED detected → ceremony')
      const { x, y, z } = getHere()
      cmd(`summon armor_stand ${x + 6} ${y + 1} ${z + 6} {CustomName:'{"text":"KING","color":"gold"}'}`)
    })
  }

  if (msg.includes('WAR_DECLARED')) {
    triggerOnce('WAR_DECLARED', () => {
      say('🔥 Director: WAR_DECLARED detected → war')
      startWar()
    })
  }

  if (msg.includes('BATTLE_VICTORY')) {
    triggerOnce('BATTLE_VICTORY', () => {
      say('🏆 Director: BATTLE_VICTORY detected → victory moment')
      const { x, y, z } = getHere()
      cmd(`summon fireworks_rocket ${x + 6} ${y + 2} ${z + 6}`)
      cmd(`summon fireworks_rocket ${x + 8} ${y + 2} ${z + 6}`)
    })
  }
}

// ----------------------------
// Chat commands (manual control)
// ----------------------------
bot.on('chat', (username, message) => {
  if (!message) return
  if (username === bot.username) return

  const m = message.trim()

  if (m === '!auto on') {
    autoEnabled = true
    say('✅ AUTO mode: ON')
    return
  }
  if (m === '!auto off') {
    autoEnabled = false
    say('🛑 AUTO mode: OFF')
    return
  }

  if (m === '!buildhut') {
    buildHut()
    return
  }
  if (m === '!spawnnpc') {
    spawnNPCs()
    return
  }
  if (m === '!war') {
    startWar()
    return
  }
})

// Also catch system messages if your server forwards story lines there
bot.on('message', (jsonMsg) => {
  try {
    const txt = jsonMsg.toString()
    if (!autoEnabled) return
    maybeTriggerFromMessage(txt)
  } catch {}
})

// ----------------------------
// Spawn init
// ----------------------------
bot.once('spawn', async () => {
  log.ok('🎬 DirectorBot spawned')

  // Keep it low spam: only a few setup commands
  cmd('gamerule sendCommandFeedback false')
  cmd('gamemode creative')
  cmd('effect give @s night_vision 999999 1 true')

  say('DirectorBot online. Commands: !buildhut, !spawnnpc, !war | !auto on/off')

  // Fix deprecated event warning (if you had physicTick previously)
  // We do nothing here, but this shows correct event name:
  bot.on('physicsTick', () => {
    // no-op
  })
})
bot.on('chat', (username, message) => {
  if (username === bot.username) return;

  console.log("CHAT:", username, message);

  if (message.trim() === "!buildhut") {
    console.log("🔥 BUILDHUT TRIGGERED");

    bot.chat("🏗️ Building hut...");

    const p = bot.entity.position;
    const x = Math.floor(p.x);
    const y = Math.floor(p.y);
    const z = Math.floor(p.z);

    bot.chat(`/fill ${x} ${y} ${z} ${x+6} ${y+4} ${z+6} oak_planks`);
  }
});
