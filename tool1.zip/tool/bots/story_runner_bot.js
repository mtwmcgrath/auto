// bots/story_runner_bot.js
const fs = require("fs");
const path = require("path");
const mineflayer = require("mineflayer");
const cfg = require("../src/config");
const log = require("../src/logger");

const EVENTS_FILE = process.env.EVENTS_FILE || "civ_sim_test.json"; // đặt trong data/events/
const CHAT_DELAY_MS = Number(process.env.CHAT_DELAY_MS || "700");

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function loadEvents() {
  const p = path.join(cfg.EVENTS_DIR, EVENTS_FILE);
  const raw = fs.readFileSync(p, "utf-8");
  const json = JSON.parse(raw);
  // hỗ trợ 2 kiểu: {events:[...]} hoặc [...]
  return Array.isArray(json) ? json : (json.events || []);
}

function eventToCommand(evt) {
  const t = (evt.type || "").toUpperCase();
  // map theo “ý nghĩa phim”
  if (t.includes("CITY_FOUNDED") || t.includes("BUILD")) return "!buildhut";
  if (t.includes("KING") || t.includes("CROWN") || t.includes("POLITIC")) return "!spawnnpc";
  if (t.includes("WAR") || t.includes("BATTLE")) return "!war";
  return null;
}

async function run() {
  const events = loadEvents();
  log.info(`Loaded events for AUTO: ${EVENTS_FILE} count= ${events.length}`);

  const bot = mineflayer.createBot({
    host: cfg.MC_HOST,
    port: cfg.MC_PORT,
    username: process.env.STORY_BOT_NAME || "StoryRunnerBot",
    version: cfg.MC_VERSION,
  });

  bot.on("login", () => log.ok("✅ StoryRunnerBot logged in"));
  bot.on("end", () => log.err("❌ StoryRunnerBot disconnected"));
  bot.on("kicked", (r) => log.err("❌ KICKED:", r));
  bot.on("error", (e) => log.err("❌ ERROR:", e.message || e));

  // đợi spawn xong
  await new Promise((resolve) => bot.once("spawn", resolve));
  await sleep(1500);

  // chạy theo event
  for (const evt of events) {
    const cmd = eventToCommand(evt);
    if (!cmd) continue;

    log.info(`AUTO -> ${evt.type} => ${cmd}`);
    bot.chat(cmd);
    await sleep(CHAT_DELAY_MS);
  }

  log.ok("✅ AUTO events done. Bot stays online.");
}

run().catch(e => {
  console.error(e);
  process.exit(1);
});
