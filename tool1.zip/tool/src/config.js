const path = require('path')
require('dotenv').config()

function must(name, fallback = null) {
  const v = process.env[name] ?? fallback
  if (!v) throw new Error(`Missing env: ${name}`)
  return v
}

module.exports = {
  mc: {
    host: must('MC_HOST', '127.0.0.1'),
    port: parseInt(must('MC_PORT', '25565'), 10),
    civUsername: must('MC_BOT_CIV_USERNAME', 'CivilizationBot'),
    camUsername: must('MC_BOT_CAM_USERNAME', 'CameraBot'),
  },
  obs: {
    url: must('OBS_WS_URL', 'ws://127.0.0.1:4455'),
    password: process.env.OBS_WS_PASSWORD ?? '',
  },
  paths: {
    recordingsDir: path.resolve(must('RECORDINGS_DIR', 'recordings')),
    markersDir: path.resolve(must('MARKERS_DIR', 'markers')),
    eventsDir: path.resolve(must('EVENTS_DIR', 'data/events')),
    outputsDir: path.resolve('outputs'),
  }
}
